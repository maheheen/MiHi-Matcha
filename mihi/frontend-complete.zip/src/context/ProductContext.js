import { createContext, useState, useEffect } from "react";

// Import default images
import ClassicMatcha from '../img/ClassicMatcha.jpg';
import VanillaMatchaLatte from '../img/VanillaMatchaLatte.jpg';
import StrawberryMatchaLatte2 from '../img/StrawberryMatchaLatte2.jpg';
import BananaCreamTopMatcha from '../img/BananaCreamTopMatcha.jpg';

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([
    { id: 1, name: "Classic Matcha", price: "Rs 900.00", image: ClassicMatcha },
    { id: 2, name: "Vanilla Matcha Latte", price: "Rs 950.00", image: VanillaMatchaLatte },
    { id: 3, name: "Strawberry Matcha Latte", price: "Rs 950.00", image: StrawberryMatchaLatte2 },
    { id: 4, name: "Banana Top Matcha", price: "Rs 1000.00", image: BananaCreamTopMatcha }
  ]);

  // Load products from localStorage on mount
  useEffect(() => {
    const savedProducts = localStorage.getItem("products");
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    }
  }, []);

  // Save products to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  const addProduct = (product) => {
    setProducts([...products, { id: Date.now(), ...product }]);
  };

  const deleteProduct = (id) => {
    setProducts(products.filter(product => product.id !== id));
  };

  return (
    <ProductContext.Provider value={{ products, addProduct, deleteProduct }}>
      {children}
    </ProductContext.Provider>
  );
};