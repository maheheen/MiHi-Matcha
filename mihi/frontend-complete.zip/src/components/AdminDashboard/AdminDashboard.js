import { useState, useContext } from "react";
import { ProductContext } from "../../context/ProductContext";
import ProductCard from "../ProductCard/ProductCard";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  const { products, addProduct, deleteProduct } = useContext(ProductContext);

  // Dummy data for orders
  const [orders, setOrders] = useState([
    { id: 1, customer: "Ali", item: "Matcha Latte", status: "Pending" },
    { id: 2, customer: "Sara", item: "Iced Matcha", status: "Pending" },
  ]);

  // Add product form state
  const [newProduct, setNewProduct] = useState({ name: "", price: "", image: "" });
  const [imagePreview, setImagePreview] = useState(null);

  // Handle image file selection
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
        setNewProduct({...newProduct, image: reader.result});
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.image) {
      alert("Please fill all fields and upload an image!");
      return;
    }

    addProduct(newProduct);
    setNewProduct({ name: "", price: "", image: "" });
    setImagePreview(null);
    alert("Product added successfully! Check the Menu page to see it.");
  };

  const handleDeleteProduct = (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      deleteProduct(id);
    }
  };

  const handleAcceptOrder = (id) => {
    setOrders(orders.map(order => order.id === id ? { ...order, status: "Accepted" } : order));
  };

  const handleRejectOrder = (id) => {
    setOrders(orders.map(order => order.id === id ? { ...order, status: "Rejected" } : order));
  };

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>

      {/* Orders Section */}
      <section className="admin-section">
        <h2>Orders</h2>
        <table className="orders-table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Item</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(order => (
              <tr key={order.id} className={order.status.toLowerCase()}>
                <td>{order.customer}</td>
                <td>{order.item}</td>
                <td>{order.status}</td>
                <td>
                  {order.status === "Pending" && (
                    <>
                      <button onClick={() => handleAcceptOrder(order.id)}>Accept</button>
                      <button onClick={() => handleRejectOrder(order.id)}>Reject</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* Add Product Section */}
      <section className="admin-section">
        <h2>Add New Product</h2>
        <div className="add-product-form">
          <input
            type="text"
            placeholder="Product Name"
            value={newProduct.name}
            onChange={e => setNewProduct({...newProduct, name: e.target.value})}
          />
          <input
            type="text"
            placeholder="Price (e.g. Rs 900.00)"
            value={newProduct.price}
            onChange={e => setNewProduct({...newProduct, price: e.target.value})}
          />
          
          <div className="image-upload-section">
            <label htmlFor="image-upload" className="upload-label">
              📷 Choose Image
            </label>
            <input
              id="image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              style={{ display: 'none' }}
            />
            {imagePreview && (
              <div className="image-preview">
                <img src={imagePreview} alt="Preview" />
              </div>
            )}
          </div>

          <button onClick={handleAddProduct}>Add Product</button>
        </div>

        <h3 style={{marginTop: '30px', color: '#174f2c'}}>Current Products ({products.length})</h3>
        <div className="product-preview">
          {products.map(product => (
            <div key={product.id} className="product-wrapper">
              <ProductCard {...product} />
              <button 
                className="delete-btn" 
                onClick={() => handleDeleteProduct(product.id)}
              >
                🗑️ Delete
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AdminDashboard;