
import Checkout from "../components/Checkout/Checkout";
// import "./CheckoutPage.css";

const CheckoutPage = ({ onBack }) => {
   return(
          <div className="check-page"> 
              <Checkout />
          </div>
      );
    
};

export default CheckoutPage;