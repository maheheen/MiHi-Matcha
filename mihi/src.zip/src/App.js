import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import { CartProvider } from './context/CartContext'; // ← ADD THIS LINE
import MenuTab from "./pages/MenuTab";
import Homepage from "./pages/Homepage";
import AboutPg from "./pages/AboutPage";
import LoginSignup from "./components/LoginSignup/LoginSignup";
import AdminDashboard from "./components/AdminDashboard/AdminDashboard";
import AdminRoute from "./components/AdminDashboard/PrivAdminRoute";
import Navbar from "./components/Navbar/Navbar";

function App() {
  return (
    <div className='App-header'>
      <CartProvider>  {/* ← ADD THIS LINE */}
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" element={<Homepage />} />      
            <Route path="/menu" element={<MenuTab />} /> 
            <Route path="/auth" element={<LoginSignup />} />
            <Route path="/about" element={<AboutPg />} /> 
            <Route 
              path="/admin/dashboard" 
              element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              } 
            />
          </Routes>
        </Router>
      </CartProvider>  {/* ← ADD THIS LINE */}
    </div>
  );
}

export default App;