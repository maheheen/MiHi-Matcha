import './Navbar.css';
import logo from '../../img/logo.jpeg';
import { Link, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleUserClick = () => {
    if (!user) navigate('/auth');
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <div className="navbar-logo">
          <img src={logo} alt="miHI Matcha Logo" className="logo-img" />
          <h1 className="brand">
            miHI <span className="brand-green">Matcha</span>
          </h1>
        </div>

        <ul className="navbar-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/menu">Menu</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><a href="#contact">Contact</a></li>
          {user?.role === 'admin' && <li><Link to="/admin/dashboard">Admin</Link></li>}
        </ul>
      </div>

      <div className="navbar-icons">
        <i className="fas fa-user navbar-icon" onClick={handleUserClick}></i>

        {user && (
          <>
            <span className="navbar-user-name">{user.name}</span>
            <button className="navbar-logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
