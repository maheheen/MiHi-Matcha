import { useState, useContext } from "react";
import { X, Plus, Minus } from "lucide-react";
import { CartContext } from "../../context/CartContext";
import "./ProductModal.css";

const ProductModal = ({ product, onClose }) => {
  const [quantity, setQuantity] = useState(1);
  const [showNotification, setShowNotification] = useState(false);
  const { addToCart, setIsCartOpen, parsePrice } = useContext(CartContext);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setShowNotification(true);
    setTimeout(() => {
      setShowNotification(false);
    }, 3000);
  };

  const increment = () => setQuantity(q => q + 1);
  const decrement = () => setQuantity(q => (q > 1 ? q - 1 : 1));

  const numericPrice = parsePrice(product.price);
  const totalPrice = numericPrice * quantity;

  return (
    <>
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal-content" onClick={e => e.stopPropagation()}>
          <button className="modal-close" onClick={onClose}>
            <X size={24} />
          </button>
          <img src={product.image} alt={product.name} className="modal-image" />
          <h2>{product.name}</h2>
          <p className="modal-description">
            {product.description || "Delicious matcha latte made with premium ingredients"}
          </p>
          <p className="modal-price">{product.price}</p>
          
          <div className="quantity-controls">
            <button onClick={decrement} className="qty-btn">
              <Minus size={18} />
            </button>
            <span className="quantity">{quantity}</span>
            <button onClick={increment} className="qty-btn">
              <Plus size={18} />
            </button>
          </div>

          <button className="add-to-cart-btn" onClick={handleAddToCart}>
            Add to Cart - Rs {totalPrice.toFixed(2)}
          </button>
        </div>
      </div>

      {showNotification && (
        <div className="notification">
          <span>✓ Item Added to Cart</span>
          <button 
            className="view-cart-btn"
            onClick={() => {
              setIsCartOpen(true);
              onClose();
            }}
          >
            View Cart
          </button>
        </div>
      )}
    </>
  );
};

export default ProductModal;