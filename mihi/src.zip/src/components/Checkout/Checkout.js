import { useContext, useState } from "react";
import { CartContext } from "../../context/CartContext";
import "./Checkout.css";

const Checkout = ({ onBack }) => {
  const { cart, cartTotal, clearCart, parsePrice } = useContext(CartContext);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });
  const [orderPlaced, setOrderPlaced] = useState(false);

  const handleSubmit = () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.address) {
      alert('Please fill in all fields');
      return;
    }
    setOrderPlaced(true);
    setTimeout(() => {
      clearCart();
      onBack();
    }, 3000);
  };

  if (orderPlaced) {
    return (
      <div className="checkout-page">
        <div className="order-success">
          <div className="success-icon">✓</div>
          <h2>Order Placed Successfully!</h2>
          <p>Thank you for your order. We'll send you a confirmation email shortly.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <button className="back-btn" onClick={onBack}>← Back to Cart</button>
      <h1>Checkout</h1>
      
      <div className="checkout-container">
        <div className="checkout-form">
          <h2>Delivery Information</h2>
          <input
            type="text"
            placeholder="Full Name"
            value={formData.name}
            onChange={e => setFormData({...formData, name: e.target.value})}
          />
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={e => setFormData({...formData, email: e.target.value})}
          />
          <input
            type="tel"
            placeholder="Phone Number"
            value={formData.phone}
            onChange={e => setFormData({...formData, phone: e.target.value})}
          />
          <textarea
            placeholder="Delivery Address"
            rows="3"
            value={formData.address}
            onChange={e => setFormData({...formData, address: e.target.value})}
          />
          <button onClick={handleSubmit} className="place-order-btn">
            Place Order - Rs {cartTotal.toFixed(2)}
          </button>
        </div>

        <div className="order-summary">
          <h2>Order Summary</h2>
          {cart.map(item => {
            const itemPrice = parsePrice(item.price);
            return (
              <div key={item.id} className="summary-item">
                <span>{item.name} x {item.quantity}</span>
                <span>Rs {(itemPrice * item.quantity).toFixed(2)}</span>
              </div>
            );
          })}
          <div className="summary-total">
            <strong>Total:</strong>
            <strong>Rs {cartTotal.toFixed(2)}</strong>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;