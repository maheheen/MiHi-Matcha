  import './Drinks.css';
  import icedmatcha from '../../img/ClassicMatcha.jpg';
  import stoberri from '../../img/StrawberryMatchaLatte2.jpg';
  import bananacream from '../../img/VanillaMatchaLatte.jpg';

  const Drinks = () => {
    return (
      <section className="signature-drinks">
        <h2 className="drinks-title">Our Signature Drinks</h2>
        <p className="drinks-subtitle">crafted with calm, love, and pure matcha</p>

        <div className="drinks-grid">
          {/* --- Drink 1 --- */}
          <div className="drink-card">
            <div className="drink-image">
              <img src={icedmatcha} alt="Iced Matcha Latte" />
            </div>
            <h3>Classic Matcha </h3>
            <p>Smooth, creamy, and perfectly balanced for sunny days.</p>
            <button className="drink-btn">Order Now</button>
          </div>

          {/* --- Drink 2 --- */}
          <div className="drink-card">
            <div className="drink-image">
              <img src={stoberri} alt="Strawberry Matcha" />
            </div>
            <h3>Strawberry Matcha</h3>
            <p>Earthy matcha meets sweet strawberries — a divine dessert sip.</p>
            <button className="drink-btn">Order Now</button>
          </div>

          {/* --- Drink 3 --- */}
          <div className="drink-card">
            <div className="drink-image">
              <img src={bananacream} alt="Vanilla Matcha Latte" />
            </div>
            <h3>Vanilla Matcha Latte</h3>
            <p>Silky cream swirls with matcha perfection.</p>
            <button className="drink-btn">Order Now</button>
          </div>
        </div>
      </section>
    );
  };

  export default Drinks;

  //proj des, grp desc, scope of work kitna bara proj hai, jo kaam karrae uss mai database involve horaha hai tou uska kia kaam hai